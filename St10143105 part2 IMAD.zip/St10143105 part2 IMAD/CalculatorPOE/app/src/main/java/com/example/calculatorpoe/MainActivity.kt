package com.example.calculatorpoe

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.TextView

class MainActivity : AppCompatActivity() {

    lateinit var display: TextView
    lateinit var editTextNumber: EditText
    lateinit var editTextNumber2: EditText
    lateinit var addition: Button
    lateinit var subtraction: Button
    lateinit var multiplication: Button
    lateinit var division: Button
    lateinit var squareRoot: Button
    lateinit var power: Button
    lateinit var statisticsfunction: Button



    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)



        display = findViewById(R.id.textView)
        editTextNumber = findViewById(R.id.editTextNumber)
        editTextNumber2 = findViewById(R.id.editTextNumber2)
        addition = findViewById(R.id.Addition)
        subtraction = findViewById(R.id.Subtraction)
        multiplication = findViewById(R.id.Multiplication)
        division = findViewById(R.id.Division)
        squareRoot = findViewById(R.id.SquareRoot)
        power = findViewById(R.id.Power)
        statisticsfunction = findViewById(R.id.StatisticsFunctions)

        addition.setOnClickListener {
            val answer1 = editTextNumber.text.toString().toInt()
            val answer2 = editTextNumber2.text.toString().toInt()
            addition(answer1,answer2)
        }

        subtraction.setOnClickListener {
            val answer1 = editTextNumber.text.toString().toInt()
            val answer2 = editTextNumber2.text.toString().toInt()

            subtraction(answer1, answer2)
        }

        multiplication.setOnClickListener {
            val answer1 = editTextNumber.text.toString().toInt()
            val answer2 = editTextNumber2.text.toString().toInt()
            multiplication(answer1, answer2)
        }
        division.setOnClickListener {
            val answer1 = editTextNumber.text.toString().toInt()
            val answer2 = editTextNumber2.text.toString().toInt()
            division(answer1, answer2)
        }
        squareRoot.setOnClickListener {
            val answer1 = editTextNumber.text.toString().toInt()
            squareRoot(answer1)
        }
        power.setOnClickListener {
            val answer1 = editTextNumber.text.toString().toInt()
            val answer2 = editTextNumber2.text.toString().toInt()
            Power(answer1, answer2)
        }
        statisticsfunction.setOnClickListener {
         val intent = Intent(this,statisticsfunctions::class.java)
            startActivity(intent)
        }

    }


    private fun addition(answer1: Int, answer2: Int) {
        val answer = answer1 + answer2
        display.text = ("answer: $answer1 + $answer2 = $answer")
    }
    private fun subtraction(answer1: Int, answer2: Int) {
        val answer = answer1 - answer2
        display.text = answer.toString()
    }
    private fun multiplication(answer1: Int, answer2: Int) {
        val answer = answer1 * answer2
        display.text = answer.toString()
    }
    private fun division(answer1: Int, answer2: Int) {
        val answer = answer1/answer2
        display.text = answer.toString()
    }
    private fun squareRoot(answer1: Int,) {
        if (answer1<0) {
            val number = answer1
            val answer = Math.sqrt(number.toDouble())
            display.text = answer.toString()
        }
    }
    private fun Power(answer1: Int, answer2: Int) {

        for(power in 0..100) {
            val answer1 = answer1
            var answer = answer1 * answer1
            display.text = ("answer: answer1^answer2 = answer")



        }
    }
}