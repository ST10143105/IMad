package com.example.calculatorpoe

import android.widget.Button
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.EditText
import android.widget.TextView

class statisticsfunctions : AppCompatActivity() {

        lateinit var userinput: EditText
        lateinit var display : TextView
        lateinit var display2: TextView
        lateinit var Addition : Button
        lateinit var Clear : Button
        lateinit var CalculateAverage: Button
        lateinit var MinimumAndMaximum : Button
        var numbers = mutableListOf<Int>()

        override fun onCreate(savedInstanceState: Bundle?) {
            super.onCreate(savedInstanceState)
            setContentView(R.layout.activity_statisticsfunctions )


            val actionBar = supportActionBar
            actionBar!!.title = "statistics"

            actionBar.setDisplayHomeAsUpEnabled(true)

            userinput =findViewById(R.id.result)
            display = findViewById(R.id.display)
            display2 = findViewById(R.id.display2)
            Addition = findViewById(R.id.addit)
            Clear = findViewById(R.id.Clear)
            CalculateAverage = findViewById(R.id.CalculateAverage)
            MinimumAndMaximum = findViewById(R.id.MinAndMax)


            Addition.setOnClickListener(){
                val input = userinput.text.toString().toInt()
                numbers.add(input)



                var buffer = ""
                numbers.forEach{
                    buffer += it.toString() + ","



                }
                display.text = buffer
                Clear.setOnClickListener(){
                    numbers.clear()
                    display.text = ""

                }
                CalculateAverage.setOnClickListener(){
                    var m= numbers
                    var sum = 0
                    for (m in numbers){
                        sum += m
                        display2.text = "The Average Is :${(sum / numbers.size.toFloat())}"
                    }

                }



                MinimumAndMaximum.setOnClickListener(){
                    var min =Int.MAX_VALUE
                    var max = 0
                    var sum = 0

                    for (number in numbers){
                        sum += number
                        if (number < min) min = number
                        if (number > max) max = number

                    }
                    display2.text = "Min:${min} Max: ${ max} "



                }

            }








        }
    }

